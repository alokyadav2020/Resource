# SignDetection > 2023-09-28 2:44pm
https://universe.roboflow.com/cvprojects-voeui/signdetection-xgjid

Provided by a Roboflow user
License: CC BY 4.0

